document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("barcodeForm");
  const barcodeType = document.getElementById("barcodeType");
  const barcodeValue = document.getElementById("barcodeValue");
  const displayValue = document.getElementById("displayValue");
  const lineColor = document.getElementById("lineColor");
  const backgroundColor = document.getElementById("backgroundColor");
  const fontSize = document.getElementById("fontSize");
  const barWidth = document.getElementById("barWidth");
  const barHeight = document.getElementById("barHeight");
  const barMargin = document.getElementById("barMargin");
  const valueHint = document.getElementById("valueHint");
  const statusMessage = document.getElementById("statusMessage");
  const previewMeta = document.getElementById("previewMeta");
  const previewEmpty = document.getElementById("previewEmpty");
  const barcodeSvg = document.getElementById("barcodeSvg");
  const downloadSvgButton = document.getElementById("downloadSvg");
  const downloadPngButton = document.getElementById("downloadPng");
  const resetButton = document.getElementById("resetButton");
  const presetButtons = document.querySelectorAll("[data-preset]");

  const typeMeta = {
    CODE128: {
      name: "Code 128",
      hint: "Best all-round choice for letters, numbers, spaces, and symbols.",
      example: "CREATIVE-VISION-2026"
    },
    CODE39: {
      name: "Code 39",
      hint: "Good for uppercase letters, digits, and a limited symbol set.",
      example: "CV-2026-001"
    },
    CODE93: {
      name: "Code 93",
      hint: "Compact alphanumeric format with stronger density than Code 39.",
      example: "VISION93"
    },
    EAN13: {
      name: "EAN-13",
      hint: "Retail format. Use 12 or 13 digits.",
      example: "5901234123457"
    },
    EAN8: {
      name: "EAN-8",
      hint: "Short retail format. Use 7 or 8 digits.",
      example: "96385074"
    },
    UPC: {
      name: "UPC-A",
      hint: "North American retail format. Use 11 or 12 digits.",
      example: "042100005264"
    },
    ITF14: {
      name: "ITF-14",
      hint: "Shipping carton format. Use 13 or 14 digits.",
      example: "10012345678903"
    },
    ITF: {
      name: "ITF",
      hint: "Digits only. Common for warehouse and logistics labels.",
      example: "0123456789"
    },
    MSI: {
      name: "MSI",
      hint: "Digits only. Common for inventory systems.",
      example: "1234567890"
    },
    MSI10: {
      name: "MSI-10",
      hint: "Digits only. MSI family with a 10-check mode.",
      example: "1234567890"
    },
    MSI11: {
      name: "MSI-11",
      hint: "Digits only. MSI family with an 11-check mode.",
      example: "1234567890"
    },
    MSI1010: {
      name: "MSI-1010",
      hint: "Digits only. MSI family with dual checksum handling.",
      example: "1234567890"
    }
  };

  const digitOnlyRules = {
    EAN13: { pattern: /^\d{12,13}$/, message: "EAN-13 needs 12 or 13 digits." },
    EAN8: { pattern: /^\d{7,8}$/, message: "EAN-8 needs 7 or 8 digits." },
    UPC: { pattern: /^\d{11,12}$/, message: "UPC-A needs 11 or 12 digits." },
    ITF14: { pattern: /^\d{13,14}$/, message: "ITF-14 needs 13 or 14 digits." },
    ITF: { pattern: /^\d+$/, message: "ITF accepts digits only." },
    MSI: { pattern: /^\d+$/, message: "MSI accepts digits only." },
    MSI10: { pattern: /^\d+$/, message: "MSI-10 accepts digits only." },
    MSI11: { pattern: /^\d+$/, message: "MSI-11 accepts digits only." },
    MSI1010: { pattern: /^\d+$/, message: "MSI-1010 accepts digits only." }
  };

  const defaults = {
    type: "CODE128",
    value: "CREATIVE-VISION-2026",
    displayValue: true,
    lineColor: "#0f172a",
    backgroundColor: "#ffffff",
    fontSize: 18,
    width: 2,
    height: 100,
    margin: 14
  };

  let renderState = {
    ...defaults
  };

  function setMessage(text, state = "") {
    statusMessage.textContent = text;
    statusMessage.dataset.state = state;
  }

  function setDownloadAvailability(enabled) {
    downloadSvgButton.disabled = !enabled;
    downloadPngButton.disabled = !enabled;
  }

  function showPreviewMessage(text, state = "warning") {
    previewEmpty.textContent = text;
    previewEmpty.dataset.state = state;
    previewEmpty.classList.remove("is-hidden");
    barcodeSvg.classList.add("is-hidden");
    setDownloadAvailability(false);
  }

  function showPreviewReady() {
    previewEmpty.classList.add("is-hidden");
    previewEmpty.removeAttribute("data-state");
    barcodeSvg.classList.remove("is-hidden");
    setDownloadAvailability(true);
  }

  function formatLabel(type) {
    return typeMeta[type]?.name || type;
  }

  function updateHint(type) {
    const meta = typeMeta[type];
    if (!meta) {
      valueHint.textContent = "Enter a barcode value and generate the barcode.";
      barcodeValue.placeholder = "Enter barcode value";
      return;
    }

    valueHint.textContent = meta.hint;
    barcodeValue.placeholder = meta.example;
  }

  function updatePreviewMeta(settings) {
    previewMeta.innerHTML = `
      <div class="meta-item">
        <span>Type</span>
        <strong>${formatLabel(settings.type)}</strong>
      </div>
      <div class="meta-item">
        <span>Value</span>
        <strong title="${escapeHtml(settings.value)}">${escapeHtml(settings.value)}</strong>
      </div>
      <div class="meta-item">
        <span>Width / Height</span>
        <strong>${settings.width} / ${settings.height}</strong>
      </div>
      <div class="meta-item">
        <span>Margin / Text</span>
        <strong>${settings.margin} / ${settings.displayValue ? "Visible" : "Hidden"}</strong>
      </div>
    `;
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function readSettings() {
    return {
      type: barcodeType.value,
      value: barcodeValue.value.trim(),
      displayValue: displayValue.checked,
      lineColor: lineColor.value,
      backgroundColor: backgroundColor.value,
      fontSize: Number(fontSize.value) || defaults.fontSize,
      width: Number(barWidth.value) || defaults.width,
      height: Number(barHeight.value) || defaults.height,
      margin: Number(barMargin.value) || defaults.margin
    };
  }

  function validateSettings(settings) {
    if (!settings.value) {
      return "Please enter a barcode value.";
    }

    const rules = digitOnlyRules[settings.type];
    if (rules && !rules.pattern.test(settings.value)) {
      return rules.message;
    }

    return "";
  }

  function renderBarcode() {
    const settings = readSettings();
    updateHint(settings.type);
    updatePreviewMeta(settings);

    const validationError = validateSettings(settings);

    if (validationError) {
      showPreviewMessage(validationError, "warning");
      setMessage(validationError, "warning");
      return false;
    }

    try {
      JsBarcode(barcodeSvg, settings.value, {
        format: settings.type,
        displayValue: settings.displayValue,
        lineColor: settings.lineColor,
        background: settings.backgroundColor,
        fontSize: settings.fontSize,
        width: settings.width,
        height: settings.height,
        margin: settings.margin,
        textMargin: 8,
        font: "Manrope"
      });

      barcodeSvg.setAttribute("aria-label", `${formatLabel(settings.type)} barcode for ${settings.value}`);
      renderState = settings;
      showPreviewReady();
      setMessage(`Generated ${formatLabel(settings.type)} barcode successfully.`, "success");
      return true;
    } catch (error) {
      showPreviewMessage(error?.message || "Unable to generate the selected barcode type.", "error");
      setMessage(error?.message || "Unable to generate the selected barcode type.", "error");
      return false;
    }
  }

  function downloadBlob(blob, filename) {
    if (!blob) {
      return;
    }

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = "none";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();

    window.setTimeout(() => URL.revokeObjectURL(url), 2500);
  }

  function getSafeFileName(extension) {
    const slug = renderState.value
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "barcode";

    return `${slug}-${renderState.type.toLowerCase()}.${extension}`;
  }

  function cloneSvgForDownload() {
    const clone = barcodeSvg.cloneNode(true);
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    clone.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
    return clone;
  }

  function downloadSvg() {
    const clone = cloneSvgForDownload();
    const svgData = new XMLSerializer().serializeToString(clone);
    const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    downloadBlob(blob, getSafeFileName("svg"));
  }

  function downloadPng() {
    const clone = cloneSvgForDownload();
    const svgData = new XMLSerializer().serializeToString(clone);
    const blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const image = new Image();

    image.onload = () => {
      const scale = 2;
      const svgWidth = Number(barcodeSvg.getAttribute("width")) || image.width || 1200;
      const svgHeight = Number(barcodeSvg.getAttribute("height")) || image.height || 400;
      const canvas = document.createElement("canvas");
      canvas.width = Math.ceil(svgWidth * scale);
      canvas.height = Math.ceil(svgHeight * scale);

      const context = canvas.getContext("2d");
      context.fillStyle = renderState.backgroundColor;
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);

      canvas.toBlob((pngBlob) => {
        downloadBlob(pngBlob, getSafeFileName("png"));
        URL.revokeObjectURL(url);
      }, "image/png");
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      setMessage("PNG export failed. Try downloading SVG instead.", "error");
    };

    image.src = url;
  }

  function applyPreset(button) {
    const presetType = button.dataset.preset;
    const presetValue = button.dataset.value || typeMeta[presetType]?.example || defaults.value;

    if (typeMeta[presetType]) {
      barcodeType.value = presetType;
      barcodeValue.value = presetValue;
      updateHint(presetType);
      renderBarcode();
    }
  }

  function resetForm() {
    barcodeType.value = defaults.type;
    barcodeValue.value = defaults.value;
    displayValue.checked = defaults.displayValue;
    lineColor.value = defaults.lineColor;
    backgroundColor.value = defaults.backgroundColor;
    fontSize.value = defaults.fontSize;
    barWidth.value = defaults.width;
    barHeight.value = defaults.height;
    barMargin.value = defaults.margin;
    updateHint(defaults.type);
    renderBarcode();
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    renderBarcode();
  });

  [barcodeType, barcodeValue, displayValue, lineColor, backgroundColor, fontSize, barWidth, barHeight, barMargin].forEach((element) => {
    element.addEventListener(element === barcodeValue ? "input" : "change", renderBarcode);
  });

  presetButtons.forEach((button) => {
    button.addEventListener("click", () => applyPreset(button));
  });

  downloadSvgButton.addEventListener("click", downloadSvg);
  downloadPngButton.addEventListener("click", downloadPng);
  resetButton.addEventListener("click", resetForm);

  updateHint(defaults.type);
  showPreviewMessage("Generate a barcode to see the live preview here.", "idle");
  renderBarcode();
});
